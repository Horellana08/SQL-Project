$(document).ready(function(){

  const tablaUsuarios=$('#tablaUsuarios').DataTable({
    "ajax":{
        "url":"api-datos.php",
        "method":'POST'

    },
    "colums":[
    {"data":"user_id"},
    {"data":"username"},
    {"data":"first_name"},
    {"data":"last_name"},
    {"data":"gender"},
    {"data":"password"},
    {"data":"status"},
    ]
  })  
})