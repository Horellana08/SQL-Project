<?php
include("conexion.php");

$query="SELECT* FROM  usuarios";

$result=$conn->query($query);

// $result->execute();
$filaDatos=array();
$i=0;

if($result){
  while($row=mysqli_fetch_array($result)){
    $filaDatos["data"][$i]=$row;
    $i++;
  }
  echo json_encode($filaDatos);
}else{
    echo ("Ha ocurrido un error");
}



?>