<?php
 $servername="localhost";
 $username="root";
 $password="";
 $database="usuario_db";

 $conn= new mysqli($servername,$username,$password,$database);

 if($conn){
   
 }else{

 }

?>